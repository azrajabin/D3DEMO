To Launch- 
goto:root
open CMD
python application.py